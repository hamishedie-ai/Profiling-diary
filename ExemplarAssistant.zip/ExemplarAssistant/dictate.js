"use strict";
const $ = (id) => document.getElementById(id);
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null;
let listening = false;

function setStatus(t) { $("status").textContent = t; }

function append(text) {
  const box = $("text");
  box.value += (box.value && !/\s$/.test(box.value) ? " " : "") + text.trim();
}

async function start() {
  if (!SR) {
    setStatus("Dictation isn't supported in this browser. Use your keyboard's microphone or Windows voice typing (Win + H) instead.");
    return;
  }
  try {
    // Asks Chrome for microphone permission (this page can show the prompt; the side panel can't).
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
  } catch (e) {
    setStatus("Microphone is blocked. Click the lock/mic icon in the address bar area, allow it, then reopen this window. Or use Win + H.");
    return;
  }
  rec = new SR();
  rec.lang = "en-AU";
  rec.continuous = true;
  rec.interimResults = false;
  rec.onresult = (ev) => {
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      if (ev.results[i].isFinal) append(ev.results[i][0].transcript);
    }
  };
  rec.onerror = (ev) => {
    if (ev.error === "not-allowed" || ev.error === "service-not-allowed") setStatus("Microphone is blocked. Allow it for this extension in Chrome, or use Win + H.");
    else if (ev.error === "no-speech") setStatus("Didn't hear anything. Keep talking, or press Pause and Resume.");
    else if (ev.error === "network") setStatus("Dictation needs an internet connection.");
    else setStatus("Dictation problem: " + ev.error);
  };
  rec.onend = () => {
    if (listening) { try { rec.start(); } catch (e) {} }
  };
  listening = true;
  rec.start();
  $("toggle").textContent = "Pause";
  setStatus("Listening... speak now.");
}

$("toggle").addEventListener("click", () => {
  if (!rec) { start(); return; }
  if (listening) {
    listening = false;
    rec.stop();
    $("toggle").textContent = "Resume";
    setStatus("Paused.");
  } else {
    listening = true;
    try { rec.start(); } catch (e) {}
    $("toggle").textContent = "Pause";
    setStatus("Listening... speak now.");
  }
});

$("add").addEventListener("click", () => {
  listening = false;
  if (rec) try { rec.stop(); } catch (e) {}
  const text = $("text").value.trim();
  if (text) chrome.runtime.sendMessage({ type: "pca-dictation", text });
  window.close();
});

$("cancel").addEventListener("click", () => {
  listening = false;
  if (rec) try { rec.stop(); } catch (e) {}
  window.close();
});

start();
