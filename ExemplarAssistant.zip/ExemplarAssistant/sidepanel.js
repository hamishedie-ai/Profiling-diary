"use strict";

const $ = (id) => document.getElementById(id);
const SITE = "https://profiling.exemplarservices.com.au/";
const FALLBACK_ACTS = [
  "Hazard / risk assessment",
  "Follow safe work procedures",
  "Obtain tools / materials",
  "Clean up / store materials",
];
const NON_WORK_ACTS = {
  "Leave": ["Leave"],
  "Leave/Training": ["Leave", "Training"],
  "Training": ["Training"],
  "Unemployed": ["Unemployed"],
};

let ref = null;
let allWorkAreas = [];
let settings = { model: "gemini-2.5-flash", defSupport: "Intermittent", dayHours: 8, defaultActs: FALLBACK_ACTS, supervisor: "" };
let manualPhotos = []; // photos added by hand: { name, dataUrl }
let photos = []; // photos used for the current run, numbered from 1 in this order
let source = "diary"; // "diary" (saved on the phone) or "new" (typed or dictated here)
let running = false;

// An error with a plain "do this" instruction for the person.
class UserError extends Error {
  constructor(message, todo) {
    super(message);
    this.todo = todo || "";
  }
}

/* ---------- small helpers ---------- */
const pad = (n) => String(n).padStart(2, "0");
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const siteDate = (d) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
const parseIso = (s) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
};
const DAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const fmtDay = (iso) => {
  const d = parseIso(iso);
  return `${DAY[d.getDay()]} ${pad(d.getDate())}/${pad(d.getMonth() + 1)}`;
};
function mondayOf(date) {
  const d = new Date(date);
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return d;
}
function weekDates() {
  const start = mondayOf(parseIso($("weekStart").value));
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
}
function activeDates() {
  return selectedDiaryDays().map(parseIso);
}
function el(tag, props = {}, children = []) {
  const e = document.createElement(tag);
  Object.assign(e, props);
  for (const c of [].concat(children)) e.append(c);
  return e;
}
function log(msg, cls = "") {
  $("log").append(el("div", { className: cls, textContent: msg }));
  $("log").scrollTop = $("log").scrollHeight;
}

/* ---------- the big status box ---------- */
let stage = "";
let stageT0 = 0;
function showStatus(kind, title, lines = [], todo = "") {
  $("status").hidden = false;
  $("status").className = "status " + kind;
  $("statusTitle").textContent = title;
  $("statusBody").textContent = "";
  lines.forEach((l) => $("statusBody").append(el("div", { textContent: l })));
  $("statusDo").textContent = todo ? "Do this: " + todo : "";
}
function renderBusy() {
  showStatus("busy", "Working...", [`${stage} (${Math.round((Date.now() - stageT0) / 1000)}s)`]);
}
function setStage(text) {
  stage = text;
  renderBusy();
}

/* ---------- settings ---------- */
async function loadSettings() {
  const saved = await chrome.storage.local.get(["apiKey", "model", "supervisor", "defSupport", "dayHours", "defaultActs"]);
  settings = { ...settings, ...saved };
  $("apiKey").value = settings.apiKey || "";
  $("model").value = settings.model || "gemini-2.5-flash";
  $("supervisor").value = settings.supervisor || "";
  $("defSupport").value = settings.defSupport || "Intermittent";
  $("dayHours").value = settings.dayHours || 8;
  renderDefaultActs();
  updateSetupState();
}
function updateSetupState() {
  const haveKey = !!settings.apiKey;
  $("setupState").textContent = haveKey ? "(done)" : "(paste your Gemini key)";
  $("setup").open = !haveKey;
}
function renderDefaultActs() {
  const box = $("defActs");
  box.textContent = "";
  const chosen = new Set(settings.defaultActs || FALLBACK_ACTS);
  for (const group of Object.keys(ref.activities)) {
    box.append(el("div", { className: "muted", textContent: group }));
    for (const a of ref.activities[group]) {
      if (["Leave", "Training", "Unemployed"].includes(a)) continue;
      const cb = el("input", { type: "checkbox", value: a, checked: chosen.has(a) });
      box.append(el("label", {}, [cb, el("span", { textContent: a })]));
    }
  }
}
async function loadModelList() {
  if (!settings.apiKey) return;
  try {
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { headers: { "x-goog-api-key": settings.apiKey } });
    if (!res.ok) return;
    const j = await res.json();
    const dl = $("modelList");
    dl.textContent = "";
    (j.models || [])
      .filter((m) => (m.supportedGenerationMethods || []).includes("generateContent") && /^models\/gemini-/.test(m.name))
      .forEach((m) => dl.append(el("option", { value: m.name.replace(/^models\//, "") })));
  } catch (e) {}
}
async function autoKey() {
  const k = $("apiKey").value.trim();
  if (!k || k === settings.apiKey) return;
  settings.apiKey = k;
  await chrome.storage.local.set({ apiKey: k });
  $("keyMsg").textContent = "Checking your key...";
  try {
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", { headers: { "x-goog-api-key": k } });
    if (!res.ok) { $("keyMsg").textContent = "Google didn't accept that key. Check you copied all of it."; return; }
    const found = await pickModel();
    if (found) { settings.model = found; $("model").value = found; await chrome.storage.local.set({ model: found }); }
    $("keyMsg").textContent = "Key saved. You're set.";
    loadModelList();
    setTimeout(updateSetupState, 1200);
  } catch (e) { $("keyMsg").textContent = "Couldn't check the key (no internet?). It's saved anyway."; }
}
async function saveSettings() {
  settings.apiKey = $("apiKey").value.trim();
  settings.model = $("model").value.trim() || "gemini-2.5-flash";
  settings.supervisor = $("supervisor").value.trim();
  settings.defSupport = $("defSupport").value;
  settings.dayHours = Number($("dayHours").value) || 8;
  settings.defaultActs = [...$("defActs").querySelectorAll("input:checked")].map((c) => c.value);
  await chrome.storage.local.set(settings);
  $("settingsMsg").textContent = "Saved.";
  loadModelList();
  updateSetupState();
  setTimeout(() => ($("settingsMsg").textContent = ""), 2000);
}

/* ---------- photos added by hand ---------- */
async function shrink(file) {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas");
  c.width = Math.round(bmp.width * scale);
  c.height = Math.round(bmp.height * scale);
  c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.8);
}
async function addPhotos(fileList) {
  for (const f of fileList) {
    try {
      manualPhotos.push({ name: f.name.replace(/\.[^.]+$/, "") + ".jpg", dataUrl: await shrink(f) });
    } catch (e) {
      log(`Couldn't read photo ${f.name}`, "bad");
    }
  }
  renderThumbs();
}
function renderThumbs() {
  const box = $("thumbs");
  box.textContent = "";
  manualPhotos.forEach((p) => box.append(el("img", { src: p.dataUrl })));
}

/* ---------- dictation (a small popup window, because the side panel can't ask for the microphone) ---------- */
function toggleMic() {
  chrome.windows.create({ url: chrome.runtime.getURL("dictate.html"), type: "popup", width: 460, height: 480 });
  $("micMsg").textContent = "A dictation window opened. Allow the microphone, speak, then press Add to my week.";
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "pca-dictation" && msg.text) {
    const box = $("story");
    box.value += (box.value && !/\s$/.test(box.value) ? " " : "") + msg.text.trim();
    $("micMsg").textContent = "Added.";
  }
});

/* ---------- Gemini ---------- */
async function pickModel() {
  const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", {
    headers: { "x-goog-api-key": settings.apiKey },
  });
  if (!res.ok) return "";
  const j = await res.json();
  const names = (j.models || [])
    .filter((m) => (m.supportedGenerationMethods || []).includes("generateContent"))
    .map((m) => m.name.replace(/^models\//, ""))
    .filter((n) => /^gemini-[\d.]+-flash/.test(n) && !/(image|tts|live|audio|embedding|thinking|exp|robotics|computer|native)/.test(n));
  const score = (n) => (/preview/.test(n) ? 0 : 1000) + (/lite/.test(n) ? 100 : 0) + parseFloat(n.match(/^gemini-([\d.]+)/)[1]);
  names.sort((x, y) => score(y) - score(x));
  return names[0] || "";
}

async function gemini(parts, schema, system, retried = false) {
  if (!settings.apiKey) throw new UserError("There's no Gemini key yet.", "Open Setup, paste your Gemini key, then press the button again.");
  const model = settings.model || "gemini-2.5-flash";
  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ role: "user", parts }],
    generationConfig: { responseMimeType: "application/json", responseSchema: schema, temperature: 0.2 },
  };
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  let res;
  for (let attempt = 0; attempt < 2; attempt++) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 90000);
    try {
      res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": settings.apiKey },
        body: JSON.stringify(body),
        signal: ctl.signal,
      });
    } catch (e) {
      if (e.name === "AbortError") {
        if (!retried) {
          const found = await pickModel();
          if (found && found !== model) {
            settings.model = found;
            $("model").value = found;
            await chrome.storage.local.set({ model: found });
            setStage(`That was slow. Trying a faster model (${found})`);
            return gemini(parts, schema, system, true);
          }
        }
        throw new UserError("Gemini is taking too long right now.", "Wait a minute and press the button again.");
      }
      throw new UserError("Couldn't reach Google.", "Check your internet connection and press the button again.");
    } finally {
      clearTimeout(timer);
    }
    if (res.status !== 503) break;
    await new Promise((r) => setTimeout(r, 2500));
  }
  if (!res.ok) {
    if (res.status === 404 && !retried) {
      // The model name isn't available any more. Ask Google what this key can use and switch.
      const found = await pickModel();
      if (found && found !== model) {
        settings.model = found;
        $("model").value = found;
        await chrome.storage.local.set({ model: found });
        setStage(`Switched to model ${found}`);
        return gemini(parts, schema, system, true);
      }
    }
    let detail = "";
    try {
      detail = ((await res.json()).error || {}).message || "";
    } catch (e) {}
    if (res.status === 404) throw new UserError(`Google doesn't have a model called "${model}" for your key.`, "Open Setup > More options and pick a model whose name starts with gemini- and ends in flash.");
    if (res.status === 429) throw new UserError("You've hit the free Gemini limit for now.", "Wait a minute (or until tomorrow) and press the button again.");
    if (res.status === 400 || res.status === 403) throw new UserError(`Google rejected the request. ${detail}`.trim().slice(0, 220), "Check your Gemini key in Setup.");
    throw new UserError(`Gemini error ${res.status}. ${detail}`.trim().slice(0, 220), "Press the button again.");
  }
  const j = await res.json();
  const text = (j.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("");
  if (!text) throw new UserError("Gemini didn't return an answer.", "Press the button again, or shorten what you wrote.");
  return JSON.parse(text.replace(/^```json\s*/i, "").replace(/```\s*$/, ""));
}

const WEEK_SCHEMA = {
  type: "OBJECT",
  properties: {
    items: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          day: { type: "STRING" },
          summary: { type: "STRING" },
          workArea: { type: "STRING" },
          hours: { type: "NUMBER" },
          support: { type: "STRING" },
          extraActivities: { type: "ARRAY", items: { type: "STRING" } },
          photoNumbers: { type: "ARRAY", items: { type: "INTEGER" } },
          needsConfirm: { type: "BOOLEAN" },
          question: { type: "STRING" },
        },
        required: ["day", "summary", "workArea", "hours", "needsConfirm"],
      },
    },
    questions: { type: "ARRAY", items: { type: "STRING" } },
  },
  required: ["items"],
};

function weekSystemPrompt() {
  const acts = Object.entries(ref.activities)
    .map(([g, list]) => `${g}: ${list.join("; ")}`)
    .join("\n");
  return `You help an electrical apprentice turn their account of their working week into entries for an official training record ("profiling card"). Accuracy matters more than completeness, because the apprentice signs off on this record.

Rules:
- Use only what the apprentice said (and what is plainly visible in their photos). Never invent jobs, tasks, sites, people or hours.
- Break the week into one entry per day per type of work. "day" must be one of the dates given (YYYY-MM-DD).
- "workArea" must be copied exactly from this list.
  Core: ${ref.coreWorkAreas.join("; ")}
  Elective: ${ref.electiveWorkAreas.join("; ")}
  Non-work: ${ref.nonWorkEntries.join("; ")}
- If the apprentice gives hours, use them. If not, share a normal working day (about ${settings.dayHours || 8} hours) sensibly across that day's jobs. Leave, sick days and training go under the non-work entries.
- If you are not sure which work area fits (for example fault finding could be Maintain / Repair or Test / Verify), pick your best guess, set needsConfirm to true, and put a short plain question in "question" saying what you think and why. If the fit is clear, set needsConfirm false and leave "question" empty.
- Conduit is PVC (plastic, non-metallic) by default. Only treat it as metallic (steel, galvanised, EMT, flexible metal) if the apprentice says so.
- The account is usually dictated by voice, so odd words are often speech-to-text mishearings (for example an unknown "unit" name that sounds like an electrical term). Work out what was most likely meant from the surrounding job and the work-area list, and carry on. Do not ask what a word means. Only put a question in "question" when two different work areas are both genuinely likely and the choice matters, and say which two.
- Decide the work area by what the job actually is, using trade knowledge and the list above. Hints: card readers, access control, door controllers, intercoms, alarms, CCTV and sensors = Install Security Systems; power points / GPOs, switches, lights, appliances and accessories = Install LV Appliances and Accessories; running cable, conduit, trays and wiring systems = Install / Fabricate LV Wiring Systems and Supports; terminating or glanding cables = Terminate LV Cables and Conductors; testing and verifying circuits = Test / Verify LV Circuits and Equipment; fault finding or repairing existing circuits = Maintain / Repair LV Circuits and Equipment; switchboards and switchgear = Mount / Connect Switchgear and Controlgear. If one entry mixes unrelated jobs (for example power points and a card reader), split it into separate entries, one per work area.
- "summary": one or two plain sentences in the apprentice's own terms of what they did. No embellishment.
- "support": Minimal, Intermittent or Constant only if the apprentice said how much supervision they had; otherwise leave it empty.
- "extraActivities": only activities from this list that the apprentice clearly did beyond the usual ones; usually empty.
${acts}
- "photoNumbers": the photos (numbered from 1 in the order shown) that belong to this entry, from what the apprentice said or what the photo shows. If a photo could belong to two entries, pick one and set needsConfirm true.
- "questions": anything else you need to ask (missing days, unclear hours). Keep each short.`;
}

/* ---------- turn the account into entries ---------- */
function normName(s) {
  return (s || "").toLowerCase().replace(/[‐-―]/g, "-").replace(/\s+/g, " ").trim();
}
function matchWorkArea(name) {
  const n = normName(name);
  return allWorkAreas.find((w) => normName(w) === n) || "";
}

async function work(story, dates) {
  const dateList = dates.map((d) => `${DAY[d.getDay()]} = ${isoDate(d)}`).join(", ");
  const parts = [
    {
      text: `${dates.length === 1 ? "Single day (everything the apprentice describes happened on this day)" : "Week"}: ${dateList}.\n\nThe apprentice's account:\n"""\n${story}\n"""\n\n${photos.length ? `${photos.length} photo(s) follow, numbered in order.` : "No photos."}`,
    },
  ];
  photos.forEach((p, i) => {
    parts.push({ text: `Photo ${i + 1}:` });
    parts.push({ inline_data: { mime_type: "image/jpeg", data: p.dataUrl.split(",")[1] } });
  });
  const out = await gemini(parts, WEEK_SCHEMA, weekSystemPrompt());
  const validDays = new Set(dates.map(isoDate));
  const items = (out.items || []).map((it) => {
    const wa = matchWorkArea(it.workArea);
    const sup = ref.supportLevels.includes(it.support) ? it.support : "";
    const extra = (it.extraActivities || []).filter((a) => Object.values(ref.activities).flat().includes(a));
    const photoNumbers = (it.photoNumbers || []).filter((n) => Number.isInteger(n) && n >= 1 && n <= photos.length);
    return {
      day: validDays.has(it.day) ? it.day : isoDate(dates[0]),
      summary: String(it.summary || "").trim(),
      workArea: wa,
      rawWorkArea: String(it.workArea || ""),
      hours: Math.max(0, Math.round((Number(it.hours) || 0) * 4) / 4),
      support: sup,
      extraActivities: extra,
      photoNumbers,
      needsConfirm: !!it.needsConfirm || !validDays.has(it.day),
      question: it.question || "",
    };
  });
  return { items, questions: out.questions || [] };
}

/* ---------- group the entries into one card entry per work area ---------- */
const SUPPORT_RANK = { "": 0, Minimal: 1, Intermittent: 2, Constant: 3 };
function aggregate(items) {
  const map = new Map();
  for (const it of items) {
    let g = map.get(it.workArea);
    if (!g) {
      const nonWork = ref.nonWorkEntries.includes(it.workArea);
      g = {
        workArea: it.workArea,
        nonWork,
        hours: 0,
        support: "",
        activities: new Set(nonWork ? NON_WORK_ACTS[it.workArea] : settings.defaultActs || FALLBACK_ACTS),
        notes: [],
        photos: new Set(),
      };
      map.set(it.workArea, g);
    }
    g.hours += it.hours;
    const s = it.support || settings.defSupport;
    if (SUPPORT_RANK[s] > SUPPORT_RANK[g.support]) g.support = s;
    it.extraActivities.forEach((a) => g.activities.add(a));
    g.notes.push(`${fmtDay(it.day)}: ${it.summary}`);
    it.photoNumbers.forEach((n) => g.photos.add(n));
  }
  return [...map.values()];
}

/* ---------- talk to the page ---------- */
async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.startsWith(SITE)) {
    throw new UserError("This tab isn't Exemplar.", "Open Exemplar in this tab, log in, go to Cards > New Card, then press the button again.");
  }
  return tab;
}
async function page(tab, cmd, args) {
  let res;
  try {
    res = await chrome.tabs.sendMessage(tab.id, { target: "pca", cmd, args });
  } catch (e) {
    throw new UserError("Can't reach the page.", "Refresh the Exemplar tab (go to Cards > New Card) and press the button again.");
  }
  if (!res) throw new UserError("Can't reach the page.", "Refresh the Exemplar tab (go to Cards > New Card) and press the button again.");
  if (!res.ok) throw new Error(res.error);
  return res.data;
}

const EQUIP_SCHEMA = {
  type: "OBJECT",
  properties: { equipment: { type: "ARRAY", items: { type: "STRING" } } },
  required: ["equipment"],
};
async function pickEquipment(group, options) {
  if (!options.length) return [];
  const system =
    "You tick equipment-range boxes on an apprentice's training record. Choose only from the options given, copied exactly. Pick only the ones that clearly match what the apprentice described, usually 1 to 6. Never add options that weren't described. If something reasonable was described, include at least one. Conduit is PVC (plastic, non-metallic) unless the apprentice says it was metal; never pick a metallic conduit option unless they said so.";
  const text = `Work area: ${group.workArea}\n\nWhat the apprentice did:\n${group.notes.join("\n")}\n\nOptions:\n${options.map((o) => "- " + o).join("\n")}`;
  const out = await gemini([{ text }], EQUIP_SCHEMA, system);
  const set = new Set(options);
  return (out.equipment || []).filter((e) => set.has(e));
}

async function fillGroups(tab, groups, dates, checks, progress) {
  const head = await page(tab, "setHeader", { start: siteDate(dates[0]), end: siteDate(dates[6]), supervisor: settings.supervisor });
  log(`Dates now show ${head.startNow} to ${head.endNow}.`);
  const digits = (s) => String(s || "").replace(/\D/g, "");
  if (head.startNow && head.endNow && (digits(head.startNow) !== digits(siteDate(dates[0])) || digits(head.endNow) !== digits(siteDate(dates[6])))) {
    checks.push(`The card shows ${head.startNow} to ${head.endNow}, not ${siteDate(dates[0])} to ${siteDate(dates[6])}. Fix the dates on the card.`);
  }
  if (head.supervisorNote) checks.push(head.supervisorNote);
  for (const g of groups) {
    progress.started = true;
    setStage(`Filling "${g.workArea}" (${g.hours} h)`);
    log(`- ${g.workArea} (${g.hours} h)...`);
    const begin = await page(tab, "beginEntry", { workArea: g.workArea });
    const equipment = g.nonWork ? [] : await pickEquipment(g, begin.equipmentOptions);
    const res = await page(tab, "fillEntry", {
      hours: g.hours,
      support: g.support,
      activities: [...g.activities],
      equipment,
      note: g.notes.join("\n"),
      photos: [...g.photos].map((n) => photos[n - 1]).filter(Boolean),
    });
    log(`  added.${res.totalHoursText ? " " + res.totalHoursText : ""}`, "ok");
    if (res.missingActivities.length) checks.push(`${g.workArea}: couldn't tick ${res.missingActivities.join(", ")}.`);
    if (res.missingEquipment.length) checks.push(`${g.workArea}: couldn't tick ${res.missingEquipment.join(", ")}.`);
    res.notes.forEach((n) => checks.push(`${g.workArea}: ${n}`));
  }
}

/* ---------- diary (Supabase): pull the days saved on the phone ---------- */
const SB_URL = "https://ulokjhbjcmbpaxdkmbui.supabase.co";
const SB_KEY = "sb_publishable_rF-n0MwPJBZlXJlEAJhFPg_u_xyQXEn"; // publishable key: safe to ship, each person only ever sees their own rows
let sb = null; // { access_token, refresh_token, expires_at, email }
const diaryPhotoCache = new Map(); // storage path -> small photo, so a second press doesn't download them again

async function sbSave(j, email) {
  sb = {
    access_token: j.access_token,
    refresh_token: j.refresh_token,
    expires_at: Math.floor(Date.now() / 1000) + (j.expires_in || 3600),
    email: email || (sb && sb.email) || (j.user && j.user.email) || "",
  };
  await chrome.storage.local.set({ diarySession: sb });
}
async function sbAuth(grant, body) {
  const res = await fetch(`${SB_URL}/auth/v1/token?grant_type=${grant}`, {
    method: "POST",
    headers: { apikey: SB_KEY, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  let j = {};
  try { j = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(j.error_description || j.msg || j.message || `Sign-in failed (${res.status}).`);
  return j;
}
async function sbToken() {
  if (!sb) throw new UserError("You're not signed in to your diary.", "Sign in under From my diary, then press the button again.");
  if (sb.expires_at - 60 < Date.now() / 1000) {
    try {
      await sbSave(await sbAuth("refresh_token", { refresh_token: sb.refresh_token }));
    } catch (e) {
      sb = null;
      await chrome.storage.local.remove("diarySession");
      renderDiary();
      throw new UserError("Your diary sign-in ran out.", "Sign in again under From my diary, then press the button again.");
    }
  }
  return sb.access_token;
}
async function sbGet(path, asBlob) {
  const res = await fetch(SB_URL + path, { headers: { apikey: SB_KEY, Authorization: "Bearer " + (await sbToken()) } });
  if (!res.ok) throw new UserError(`The diary didn't answer (error ${res.status}).`, "Press the button again. If it keeps happening, sign out and back in.");
  return asBlob ? res.blob() : res.json();
}
function renderDiary() {
  $("sbOut").hidden = !!sb;
  $("sbIn").hidden = !sb;
  if (sb) $("sbWho").textContent = sb.email ? `Signed in as ${sb.email}` : "Signed in";
}
async function diarySignIn() {
  const email = $("sbEmail").value.trim();
  const password = $("sbPassword").value;
  if (!email || !password) { $("sbMsg").textContent = "Enter your diary email and password."; return; }
  $("sbMsg").textContent = "Signing in...";
  try {
    await sbSave(await sbAuth("password", { email, password }), email);
    $("sbPassword").value = "";
    $("sbMsg").textContent = "";
    renderDiary();
    refreshCalendar();
  } catch (e) {
    $("sbMsg").textContent = e.message;
  }
}
async function diarySignOut() {
  sb = null;
  await chrome.storage.local.remove("diarySession");
  $("sbMsg").textContent = "";
  renderDiary();
  refreshCalendar();
}

/* ---------- week calendar (diary) ---------- */
let cal = { saved: new Set(), off: new Set(), loaded: false, error: "", rows: {}, preview: "" };
function selectedDiaryDays() {
  return weekDates().map(isoDate).filter((d) => cal.saved.has(d) && !cal.off.has(d));
}
function calLabel() {
  const wd = weekDates();
  return `Week from ${siteDate(wd[0])} to ${siteDate(wd[6])}`;
}
async function refreshCalendar(keepOff) {
  $("calRange").textContent = calLabel();
  cal.saved = new Set();
  cal.rows = {};
  if (!keepOff) { cal.off = new Set(); cal.preview = ""; }
  cal.loaded = false;
  cal.error = "";
  renderCalendar();
  if (source !== "diary" || !sb) return;
  const wd = weekDates();
  const mine = wd[0].getTime();
  try {
    const rows = await sbGet(`/rest/v1/daily_entries?select=id,entry_date,transcript&entry_date=gte.${isoDate(wd[0])}&entry_date=lte.${isoDate(wd[6])}`);
    if (weekDates()[0].getTime() !== mine) return; // moved to another week meanwhile
    cal.saved = new Set(rows.filter((r) => (r.transcript || "").trim()).map((r) => r.entry_date));
    rows.forEach((r) => { cal.rows[r.entry_date] = r; });
    cal.loaded = true;
  } catch (e) {
    cal.error = e.message || "Couldn't check the diary.";
  }
  renderCalendar();
}
function renderCalendar() {
  const box = $("calDays");
  box.textContent = "";
  const wd = weekDates();
  wd.forEach((d) => {
    const iso = isoDate(d);
    const saved = cal.saved.has(iso);
    const off = cal.off.has(iso);
    const weekend = d.getDay() === 0 || d.getDay() === 6;
    const cls = !cal.loaded ? "day" : saved ? (off ? "day off" : "day saved") : weekend ? "day weekend" : "day missing";
    const mark = !cal.loaded ? "·" : saved ? (off ? "–" : "✓") : weekend ? "" : "✗";
    const b = el("button", { className: cls + (cal.preview === iso ? " sel" : ""), type: "button", disabled: !cal.loaded || !sb });
    b.append(el("span", { className: "dn", textContent: DAY[d.getDay()] }), el("span", { className: "dd", textContent: String(d.getDate()) }), el("span", { className: "mk", textContent: mark }));
    b.title = !cal.loaded ? "" : saved ? (off ? "Left out. Tap to put it back." : "Saved. Tap to leave it out.") : "Nothing saved. Tap to add an entry for this day.";
    b.addEventListener("click", () => {
      if (!saved) { openNew(iso); return; }
      cal.preview = cal.preview === iso ? "" : iso;
      renderCalendar();
    });
    box.append(b);
  });
  const n = selectedDiaryDays().length;
  renderPreview();
  $("calMsg").textContent = cal.error ? cal.error : !sb ? "Sign in to see which days you saved." : !cal.loaded ? "Checking your diary..." : n ? `${n} day${n === 1 ? "" : "s"} will be filled. Tap a ✗ to add that day.` : "No saved days this week. Tap a day to add one.";
}
let previewToken = 0;
function renderPreview() {
  const iso = cal.preview;
  const row = iso && cal.rows[iso];
  $("calPreview").hidden = !row;
  if (!row) return;
  const mine = ++previewToken;
  $("prevTitle").textContent = fmtDay(iso);
  $("prevText").textContent = (row.transcript || "").trim();
  $("prevThumbs").textContent = "";
  $("prevToggle").textContent = cal.off.has(iso) ? "Put this day back" : "Leave this day out";
  loadPreviewPhotos(row.id, mine);
}
async function loadPreviewPhotos(entryId, mine) {
  try {
    const pics = await sbGet(`/rest/v1/entry_photos?select=storage_path&entry_id=eq.${entryId}&order=created_at.asc`);
    for (const p of pics) {
      let dataUrl = diaryPhotoCache.get(p.storage_path);
      if (!dataUrl) {
        const blob = await sbGet(`/storage/v1/object/authenticated/profiling-photos/${p.storage_path.split("/").map(encodeURIComponent).join("/")}`, true);
        dataUrl = await shrink(blob);
        diaryPhotoCache.set(p.storage_path, dataUrl);
      }
      if (mine !== previewToken) return;
      $("prevThumbs").append(el("img", { src: dataUrl }));
    }
  } catch (e) {
    /* photos are optional in the preview */
  }
}
function pickWeek() {
  const i = $("weekStart");
  if (typeof i.showPicker === "function") { try { i.showPicker(); return; } catch (e) {} }
  i.focus && i.focus();
}
function moveWeek(delta) {
  const d = mondayOf(parseIso($("weekStart").value));
  d.setDate(d.getDate() + 7 * delta);
  $("weekStart").value = isoDate(d);
  refreshCalendar();
}

// Gets the saved days (and their photos) for the chosen day or week. Returns the account text and the photos.
async function collectDiary(dates) {
  await sbToken(); // fails with a plain message if not signed in
  const from = isoDate(dates[0]);
  const to = isoDate(dates[dates.length - 1]);
  const days = await sbGet(`/rest/v1/daily_entries?select=id,entry_date,transcript&entry_date=in.(${dates.map(isoDate).join(",")})&order=entry_date.asc`);
  if (!days.length) {
    throw new UserError(
      from === to ? `Nothing is saved in your diary for ${fmtDay(from)}.` : `Nothing is saved in your diary for ${fmtDay(from)} to ${fmtDay(to)}.`,
      "Pick a different day or week, or use Create new entries."
    );
  }
  const ids = days.map((d) => d.id).join(",");
  const pics = await sbGet(`/rest/v1/entry_photos?select=entry_id,storage_path&entry_id=in.(${ids})&order=created_at.asc`);
  const list = [];
  const numsByEntry = {};
  let failed = 0;
  for (const p of pics) {
    let dataUrl = diaryPhotoCache.get(p.storage_path);
    if (!dataUrl) {
      try {
        const blob = await sbGet(`/storage/v1/object/authenticated/profiling-photos/${p.storage_path.split("/").map(encodeURIComponent).join("/")}`, true);
        dataUrl = await shrink(blob);
        diaryPhotoCache.set(p.storage_path, dataUrl);
      } catch (e) {
        if (e instanceof UserError && /sign/i.test(e.todo) && !sb) throw e;
        failed++;
        continue;
      }
    }
    list.push({ name: p.storage_path.split("/").pop().replace(/\.[^.]+$/, "") + ".jpg", dataUrl });
    (numsByEntry[p.entry_id] = numsByEntry[p.entry_id] || []).push(list.length);
  }
  const story = days
    .filter((d) => (d.transcript || "").trim())
    .map((d) => {
      const nums = numsByEntry[d.id];
      return `${DAY[parseIso(d.entry_date).getDay()]} ${d.entry_date}: ${d.transcript.trim()}${nums ? ` (Photos from this day: ${nums.join(", ")}.)` : ""}`;
    })
    .join("\n\n");
  if (!story) throw new UserError("Your saved days have no text, only photos.", "Add what you did in the diary app, or use Create new entries.");
  return { story, photoList: list, dayCount: days.length, failedPhotos: failed };
}

/* ---------- adding a day to the diary ---------- */
function userId() {
  try {
    const p = sb.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(p)).sub;
  } catch (e) {
    return "";
  }
}
async function sbSend(method, path, body, headers = {}, raw) {
  const res = await fetch(SB_URL + path, {
    method,
    headers: { apikey: SB_KEY, Authorization: "Bearer " + (await sbToken()), ...(raw ? {} : { "Content-Type": "application/json" }), ...headers },
    body: raw ? body : body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) throw new UserError(`The diary didn't save it (error ${res.status}).`, "Press the button again. If it keeps happening, sign out and back in.");
  return res.status === 204 ? null : res.json().catch(() => null);
}
function openNew(iso) {
  $("entryDate").value = iso;
  setSource("new");
  $("story").focus && $("story").focus();
}
async function addToDiary() {
  await sbToken();
  const day = $("entryDate").value;
  if (!day) throw new UserError("No day is chosen.", "Pick the day this entry is for.");
  const text = $("story").value.trim();
  if (!text && !manualPhotos.length) throw new UserError("There's nothing to save yet.", "Type or dictate what you did, then press the button again.");
  const uid = userId();
  if (!uid) throw new UserError("Your diary sign-in looks wrong.", "Sign out, sign in again, then press the button again.");
  setStage(`Saving ${fmtDay(day)} to your diary`);
  const existing = await sbGet(`/rest/v1/daily_entries?select=id,transcript&entry_date=eq.${day}`);
  let id;
  if (existing.length) {
    id = existing[0].id;
    const joined = [(existing[0].transcript || "").trim(), text].filter(Boolean).join("\n\n");
    await sbSend("PATCH", `/rest/v1/daily_entries?id=eq.${id}`, { transcript: joined });
  } else {
    const made = await sbSend("POST", "/rest/v1/daily_entries", { user_id: uid, entry_date: day, transcript: text, status: "draft" }, { Prefer: "return=representation" });
    id = made && made[0] && made[0].id;
    if (!id) throw new UserError("The diary didn't confirm the save.", "Press the button again.");
  }
  let failed = 0;
  for (let n = 0; n < manualPhotos.length; n++) {
    try {
      const blob = await (await fetch(manualPhotos[n].dataUrl)).blob();
      const path = `${uid}/${day}/${Date.now()}-${n}.jpg`;
      await sbSend("POST", `/storage/v1/object/profiling-photos/${path.split("/").map(encodeURIComponent).join("/")}`, blob, { "Content-Type": "image/jpeg", "x-upsert": "true" }, true);
      await sbSend("POST", "/rest/v1/entry_photos", { entry_id: id, user_id: uid, storage_path: path });
    } catch (e) {
      failed++;
    }
  }
  const added = manualPhotos.length - failed;
  $("story").value = "";
  manualPhotos = [];
  renderThumbs();
  $("weekStart").value = day;
  setSource("diary");
  showStatus(failed ? "bad" : "ok", failed ? "Saved, with a problem" : "Done", [
    `${fmtDay(day)} is saved to your diary${added ? ` with ${added} photo${added === 1 ? "" : "s"}` : ""}.`,
    ...(failed ? [`${failed} photo${failed === 1 ? "" : "s"} didn't upload. Add ${failed === 1 ? "it" : "them"} again on your phone app.`] : []),
  ], "Now press Fill my card to put your diary onto the card.");
}

/* ---------- the one button ---------- */
async function runAll() {
  if (running) return;
  running = true;
  $("go").disabled = true;
  $("draft").hidden = true;
  $("log").textContent = "";
  stageT0 = Date.now();
  const timer = setInterval(renderBusy, 1000);
  const progress = { started: false };
  try {
    if (source === "new") {
      await addToDiary();
      return;
    }
    if (!$("weekStart").value) throw new UserError("No week is chosen.", "Pick the week above.");
    if (!settings.apiKey) throw new UserError("There's no Gemini key yet.", "Open Setup, paste your Gemini key, then press the button again.");

    setStage("Checking Exemplar");
    const tab = await activeTab();
    const info = await page(tab, "ping");
    if (!info.onForm) throw new UserError("Exemplar isn't on a New Card page.", "Go to Cards > New Card on Exemplar, then press the button again.");

    let dates = activeDates();
    let input;
    {
      setStage("Getting your days from the diary");
      await sbToken();
      await refreshCalendar(true);
      dates = activeDates();
      if (!dates.length) throw new UserError(`No saved days are ticked for ${siteDate(weekDates()[0])} to ${siteDate(weekDates()[6])}.`, "Pick another week, put a day back in the calendar, or use Create new entries.");
      input = await collectDiary(dates);
    }
    photos = input.photoList;

    setStage("Working out your entries");
    const { items, questions } = await work(input.story, dates);
    const usable = items.filter((it) => it.workArea && it.hours > 0);
    const skipped = items.filter((it) => !(it.workArea && it.hours > 0));
    if (!usable.length) throw new UserError("I couldn't find anything to put on the card.", "Add more detail about what you did and roughly how long, then press the button again.");

    const checks = [];
    skipped.forEach((it) => checks.push(`Left out: ${fmtDay(it.day)} "${it.summary.slice(0, 60)}" (no matching work area or hours). Add it by hand.`));
    usable.filter((it) => it.needsConfirm).forEach((it) => checks.push(`${fmtDay(it.day)}, ${it.workArea}: ${it.question || "best guess, please check."}`));
    questions.forEach((q) => checks.push(`Gemini asks: ${q}`));
    if (input.failedPhotos) checks.push(`${input.failedPhotos} photo${input.failedPhotos === 1 ? "" : "s"} couldn't be downloaded, so ${input.failedPhotos === 1 ? "it wasn't" : "they weren't"} attached.`);

    const groups = aggregate(usable);
    await fillGroups(tab, groups, weekDates(), checks, progress);

    const total = groups.reduce((s, g) => s + g.hours, 0);
    const wd = weekDates();
    const lines = [`Filled ${groups.length} work area entr${groups.length === 1 ? "y" : "ies"}, ${total} hours, for ${siteDate(wd[0])} to ${siteDate(wd[6])}.`];
    if (checks.length) {
      lines.push("Check these on the card:");
      checks.forEach((c) => lines.push("- " + c));
    }
    showStatus("ok", "Done", lines, "Look the card over on the page, then press Save as Draft. Submit it on the site yourself.");
    $("draft").hidden = false;
  } catch (e) {
    let msg = e.message || String(e);
    let todo = e.todo || "";
    if (e.name === "TypeError") {
      msg = "Couldn't reach the internet.";
      todo = "Check your connection and press the button again.";
    }
    if (!todo) todo = "Press the button again. If it keeps happening, tell Claude exactly what this says.";
    if (progress.started) todo += " Some entries may already be on the card, so refresh Cards > New Card first or nothing gets added twice.";
    showStatus("bad", "Error", [msg], todo);
    log("Stopped: " + msg, "bad");
  } finally {
    clearInterval(timer);
    running = false;
    $("go").disabled = false;
  }
}

async function saveDraft() {
  try {
    const tab = await activeTab();
    await page(tab, "saveDraft");
    showStatus("ok", "Draft pressed", ["Pressed Save as Draft on the site."], "Check it saved on the site, then submit it yourself when you're happy.");
    $("draft").hidden = true;
  } catch (e) {
    showStatus("bad", "Error", [e.message], e.todo || "Press Save as Draft on the site yourself.");
  }
}

/* ---------- source choice ---------- */
function setSource(s, save = true) {
  source = s === "new" ? "new" : "diary";
  $("srcDiary").classList.toggle("on", source === "diary");
  $("srcNew").classList.toggle("on", source === "new");
  $("paneDiary").hidden = source !== "diary";
  $("paneNew").hidden = source !== "new";
  if (save) chrome.storage.local.set({ source });
  $("calWrap").hidden = source !== "diary";
  $("go").textContent = source === "diary" ? "Fill my card" : "Add to my diary";
  if (typeof refreshCalendar === "function" && ref) refreshCalendar();
}

/* ---------- start up ---------- */
(async function init() {
  ref = await (await fetch(chrome.runtime.getURL("reference.json"))).json();
  allWorkAreas = [...ref.coreWorkAreas, ...ref.electiveWorkAreas, ...ref.nonWorkEntries];
  $("weekStart").value = isoDate(mondayOf(new Date()));
  await loadSettings();
  const stored = await chrome.storage.local.get(["diarySession", "source"]);
  if (stored.diarySession) sb = stored.diarySession;
  setSource(stored.source, false);
  renderDiary();
  refreshCalendar();
  loadModelList();
  $("apiKey").addEventListener("change", autoKey);
  $("apiKey").addEventListener("paste", () => setTimeout(autoKey, 100));
  $("saveSettings").addEventListener("click", saveSettings);
  $("srcDiary").addEventListener("click", () => setSource("diary"));
  $("srcNew").addEventListener("click", () => setSource("new"));
  $("sbSignIn").addEventListener("click", diarySignIn);
  $("wkPrev").addEventListener("click", () => moveWeek(-1));
  $("wkNext").addEventListener("click", () => moveWeek(1));
  $("calRange").addEventListener("click", pickWeek);
  $("prevClose").addEventListener("click", () => { cal.preview = ""; renderCalendar(); });
  $("prevToggle").addEventListener("click", () => {
    const iso = cal.preview;
    if (!iso) return;
    if (cal.off.has(iso)) cal.off.delete(iso); else cal.off.add(iso);
    renderCalendar();
  });
  $("weekStart").addEventListener("change", () => {
    if ($("weekStart").value) $("weekStart").value = isoDate(mondayOf(parseIso($("weekStart").value)));
    refreshCalendar();
  });
  $("sbSignOut").addEventListener("click", diarySignOut);
  $("photos").addEventListener("change", async (e) => { await addPhotos([...e.target.files]); e.target.value = ""; });
  $("mic").addEventListener("click", toggleMic);
  $("go").addEventListener("click", runAll);
  $("draft").addEventListener("click", saveDraft);
})();

window.addEventListener("error", (e) => showStatus("bad", "Error", [e.message || String(e)], "Press the button again. If it keeps happening, tell Claude exactly what this says."));
window.addEventListener("unhandledrejection", (e) => showStatus("bad", "Error", [(e.reason && e.reason.message) || String(e.reason)], "Press the button again. If it keeps happening, tell Claude exactly what this says."));
